
-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `RoomNumber` int(11) NOT NULL,
  `RoomType` varchar(50) NOT NULL,
  `BedType` varchar(50) DEFAULT NULL,
  `Rate` decimal(10,2) NOT NULL,
  `Availability` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`RoomNumber`, `RoomType`, `BedType`, `Rate`, `Availability`) VALUES
(1, 'Single', 'Queen', 1000.00, 1),
(2, 'Double', 'King', 1500.00, 0),
(3, 'Suite', 'King', 2500.00, 1),
(4, 'Single', 'Twin', 900.00, 0),
(5, 'Double', 'Queen', 1600.00, 0);
