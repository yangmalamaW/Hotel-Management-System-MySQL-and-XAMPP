
-- --------------------------------------------------------

--
-- Table structure for table `foodorders`
--

CREATE TABLE `foodorders` (
  `OrderID` int(11) NOT NULL,
  `GuestID` int(11) DEFAULT NULL,
  `OrderDate` date DEFAULT NULL,
  `TotalAmount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foodorders`
--

INSERT INTO `foodorders` (`OrderID`, `GuestID`, `OrderDate`, `TotalAmount`) VALUES
(1, 1, '2024-04-01', 800.00),
(2, 2, '2024-04-03', 1200.00),
(3, 3, '2024-04-02', 900.00),
(4, 4, '2024-04-04', 1100.00),
(5, 5, '2024-04-05', 950.00);
