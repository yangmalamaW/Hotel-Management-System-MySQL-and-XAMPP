
-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `ReservationID` int(11) NOT NULL,
  `GuestID` int(11) DEFAULT NULL,
  `RoomNumber` int(11) DEFAULT NULL,
  `CheckInDate` date DEFAULT NULL,
  `CheckOutDate` date DEFAULT NULL,
  `TotalAmount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`ReservationID`, `GuestID`, `RoomNumber`, `CheckInDate`, `CheckOutDate`, `TotalAmount`) VALUES
(1, 1, 1, '2024-04-01', '2024-04-05', 4000.00),
(2, 2, 3, '2024-04-03', '2024-04-07', 1000.00),
(3, 3, 2, '2024-04-02', '2024-04-03', 6000.00),
(4, 4, 4, '2024-04-04', '2024-04-08', 4000.00),
(5, 5, 5, '2024-04-05', '2024-04-08', 6400.00);
