
-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `GuestID` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guests`
--

INSERT INTO `guests` (`GuestID`, `FirstName`, `LastName`, `Email`, `PhoneNumber`) VALUES
(1, 'John', 'Doe', 'doe.john@hotmail.com', '980-456-7890'),
(2, 'Will', 'Smith', 'will.smith@yahoo.com', '981-88-7207'),
(3, 'Michael', 'Jackson', 'michael.jackson@gmail.com', '986-789-0123'),
(4, 'Bob', 'Builder', 'bob.builder@gmail.com', '984-012-3456'),
(5, 'Emily', 'Brown', 'emily.brown@gmail.com', '980-345-6789');
